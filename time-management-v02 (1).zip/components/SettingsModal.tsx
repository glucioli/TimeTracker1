
import React from 'react';
import { CloseIcon, DownloadIcon, DevicePhoneMobileIcon, ClipboardDocumentIcon, ArrowTopRightOnSquareIcon } from './Icons';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onReset: () => void;
  onExportCsv: () => void;
  onExportExcel: () => void;
  showInstallButton?: boolean;
  onInstall?: () => void;
  currentUrl?: string;
  isBlobUrl?: boolean;
}

const SettingsModal: React.FC<SettingsModalProps> = ({ 
  isOpen, 
  onClose, 
  onReset, 
  onExportCsv, 
  onExportExcel,
  showInstallButton,
  onInstall,
  currentUrl,
  isBlobUrl
}) => {
  if (!isOpen) return null;

  const handleCopyUrl = async () => {
    if (!currentUrl) return;
    try {
        await navigator.clipboard.writeText(currentUrl);
        alert('Indirizzo copiato!');
    } catch (err) {
        const textArea = document.createElement("textarea");
        textArea.value = currentUrl;
        textArea.style.position = "fixed";
        textArea.style.left = "-9999px";
        document.body.appendChild(textArea);
        textArea.focus();
        textArea.select();
        try {
            document.execCommand('copy');
            alert('Indirizzo copiato!');
        } catch (err2) {
            alert('Copia manualmente il testo sotto.');
        }
        document.body.removeChild(textArea);
    }
  };

  return (
    <div
      className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50"
      onClick={onClose}
      aria-modal="true"
      role="dialog"
    >
      <div
        className="bg-slate-800 border border-slate-700 rounded-2xl w-full max-w-md m-4 p-6 shadow-2xl relative animate-fade-in max-h-[90vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex justify-between items-center mb-6 sticky top-0 bg-slate-800 pt-2 pb-2 z-10 border-b border-slate-700/50">
          <h2 className="text-2xl font-bold text-slate-100">Impostazioni</h2>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white transition-colors"
            aria-label="Chiudi impostazioni"
          >
            <CloseIcon className="h-7 w-7" />
          </button>
        </div>

        <div className="space-y-8 pb-4">
            
             {/* Sezione Versione Permanente */}
             <div>
                <h3 className="text-lg font-semibold text-emerald-400 mb-2">Versione Permanente (GitHub)</h3>
                <div className="bg-emerald-900/10 border border-emerald-500/30 rounded-lg p-4">
                    <p className="text-sm text-slate-300 mb-3 font-semibold">
                        IMPORTANTE: Se vedi "Page Not Found", devi aggiornare i file!
                    </p>
                    <ol className="list-decimal list-inside text-sm text-slate-200 space-y-2">
                        <li>Scarica il nuovo ZIP cliccando <DownloadIcon className="inline h-4 w-4 align-text-bottom"/> in alto.</li>
                        <li>Vai sul tuo repository <strong>GitHub</strong>.</li>
                        <li>Clicca "Add file" -> "Upload files".</li>
                        <li>Trascina <strong>TUTTI</strong> i nuovi file (incluso <code>netlify.toml</code>).</li>
                        <li>Clicca "Commit changes".</li>
                    </ol>
                    <p className="text-xs text-slate-400 mt-2">
                        Il nuovo file <code>netlify.toml</code> correggerà automaticamente l'errore su Netlify.
                    </p>
                </div>
            </div>

            {/* Address Section */}
            <div>
                 <h3 className="text-lg font-semibold text-slate-300 mb-2">Link Anteprima Attuale</h3>
                 <div className="bg-slate-700/50 border border-slate-600 rounded-lg p-3">
                     {isBlobUrl ? (
                         <p className="text-sm text-red-300">
                             Attenzione: Stai usando un link privato. Usa il metodo "Publish/Share" in alto a destra o installa via GitHub.
                         </p>
                     ) : (
                        <>
                         <div className="flex items-center gap-2">
                             <code className="flex-1 bg-slate-900 p-2 rounded text-xs font-mono text-sky-300 break-all select-all">
                                 {currentUrl || "..."}
                             </code>
                             <button 
                                onClick={handleCopyUrl}
                                className="p-2 bg-slate-600 hover:bg-slate-500 rounded text-white transition-colors"
                                title="Copia Link"
                             >
                                 <ClipboardDocumentIcon className="h-5 w-5" />
                             </button>
                         </div>
                         </>
                     )}
                 </div>
            </div>

            {showInstallButton && (
            <div>
                <h3 className="text-lg font-semibold text-slate-300 mb-2">Installazione Rapida</h3>
                <div className="bg-violet-900/20 border border-violet-500/30 rounded-lg p-4 flex items-center justify-between">
                    <div>
                        <p className="font-bold text-violet-200">Installa App</p>
                        <p className="text-sm text-violet-300/80">Usa come app nativa</p>
                    </div>
                    <button
                        onClick={onInstall}
                        className="bg-violet-600 hover:bg-violet-700 text-white font-bold py-2 px-4 rounded-lg transition-colors focus:outline-none focus:ring-2 focus:ring-violet-500 focus:ring-offset-2 focus:ring-offset-slate-800 flex items-center gap-2"
                    >
                        <DevicePhoneMobileIcon />
                        <span>Installa</span>
                    </button>
                </div>
            </div>
            )}

            <div>
                <h3 className="text-lg font-semibold text-slate-300 mb-2">Esportazione Dati</h3>
                <div className="bg-slate-700/50 border border-slate-600 rounded-lg p-4 space-y-4">
                    <div className="flex items-center justify-between">
                        <div>
                            <p className="font-bold text-slate-200">Esporta Excel</p>
                            <p className="text-sm text-slate-400">Migliore per PC</p>
                        </div>
                        <button
                            onClick={onExportExcel}
                            className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-2 px-4 rounded-lg transition-colors focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:ring-offset-2 focus:ring-offset-slate-800 flex items-center gap-2"
                        >
                            <DownloadIcon />
                            <span>Excel</span>
                        </button>
                    </div>

                    <div className="flex items-center justify-between border-t border-slate-600 pt-4">
                         <div>
                            <p className="font-bold text-slate-200">Esporta CSV</p>
                            <p className="text-sm text-slate-400">Formato semplice</p>
                        </div>
                        <button
                            onClick={onExportCsv}
                            className="bg-sky-600 hover:bg-sky-700 text-white font-bold py-2 px-4 rounded-lg transition-colors focus:outline-none focus:ring-2 focus:ring-sky-500 focus:ring-offset-2 focus:ring-offset-slate-800 flex items-center gap-2"
                        >
                            <DownloadIcon />
                            <span>CSV</span>
                        </button>
                    </div>
                </div>
            </div>

            <div>
                <h3 className="text-lg font-semibold text-slate-300 mb-2">Area Pericolosa</h3>
                <div className="bg-red-900/20 border border-red-500/30 rounded-lg p-4 flex items-center justify-between">
                    <div>
                        <p className="font-bold text-red-200">Resetta Tutto</p>
                        <p className="text-sm text-red-300/80">Cancella tutti i dati.</p>
                    </div>
                    <button
                        onClick={onReset}
                        className="bg-red-600 hover:bg-red-700 text-white font-bold py-2 px-4 rounded-lg transition-colors focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-offset-2 focus:ring-offset-slate-800"
                    >
                        Resetta
                    </button>
                </div>
            </div>
        </div>
      </div>
    </div>
  );
};

export default SettingsModal;
