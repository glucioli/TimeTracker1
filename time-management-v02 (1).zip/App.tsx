import React, { useState, useEffect, useMemo, useCallback } from 'react';
import TaskTimer from './components/TaskTimer';
import SummaryPanel from './components/SummaryPanel';
import TimeSheet from './components/TimeSheet';
import SettingsModal from './components/SettingsModal';
import { SettingsIcon, DevicePhoneMobileIcon, ClipboardDocumentIcon } from './components/Icons';
import { TASKS, LOCAL_STORAGE_KEY_ENTRIES, LOCAL_STORAGE_KEY_TIMER } from './constants';
import type { TimeEntry, ActiveTimer, Task } from './types';

// Helper to safely parse JSON from localStorage
const loadJSON = <T,>(key: string, fallback: T): T => {
  try {
    const item = window.localStorage.getItem(key);
    return item ? JSON.parse(item) : fallback;
  } catch (error) {
    console.error(`Error reading from localStorage key "${key}":`, error);
    return fallback;
  }
};

const App: React.FC = () => {
  const [timeEntries, setTimeEntries] = useState<TimeEntry[]>(() =>
    loadJSON<TimeEntry[]>(LOCAL_STORAGE_KEY_ENTRIES, [])
  );
  const [activeTimer, setActiveTimer] = useState<ActiveTimer | null>(() =>
    loadJSON<ActiveTimer | null>(LOCAL_STORAGE_KEY_TIMER, null)
  );
  const [currentTime, setCurrentTime] = useState<number>(Date.now());
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [isIframe, setIsIframe] = useState(false);
  const [currentUrl, setCurrentUrl] = useState('');
  const [isBlobUrl, setIsBlobUrl] = useState(false);

  // Check if running in iframe (preview mode) and get URL
  useEffect(() => {
    try {
      setIsIframe(window.self !== window.top);
      const href = window.location.href;
      setCurrentUrl(href);
      // Detect if the URL is a blob (internal preview) which cannot be shared
      setIsBlobUrl(href.startsWith('blob:'));
    } catch (e) {
      setIsIframe(true);
    }
  }, []);

  // Update current time every second to re-render timers
  useEffect(() => {
    const intervalId = setInterval(() => {
      setCurrentTime(Date.now());
    }, 1000);
    return () => clearInterval(intervalId);
  }, []);

  // Handle PWA install prompt
  useEffect(() => {
    const handleBeforeInstallPrompt = (e: any) => {
      // Prevent the mini-infobar from appearing on mobile
      e.preventDefault();
      // Stash the event so it can be triggered later.
      setDeferredPrompt(e);
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    };
  }, []);

  // Persist timeEntries to localStorage
  useEffect(() => {
    try {
      window.localStorage.setItem(LOCAL_STORAGE_KEY_ENTRIES, JSON.stringify(timeEntries));
    } catch (error) {
      console.error('Error writing timeEntries to localStorage:', error);
    }
  }, [timeEntries]);

  // Persist activeTimer to localStorage
  useEffect(() => {
    try {
      window.localStorage.setItem(LOCAL_STORAGE_KEY_TIMER, JSON.stringify(activeTimer));
    } catch (error) {
      console.error('Error writing activeTimer to localStorage:', error);
    }
  }, [activeTimer]);
  
  const handleToggleTimer = useCallback((taskId: string) => {
    const now = Date.now();

    setActiveTimer(prevTimer => {
        // If a timer is currently running...
        if (prevTimer) {
            // ...stop it and create a new time entry for it.
            const newEntry: TimeEntry = {
                id: crypto.randomUUID(),
                taskId: prevTimer.taskId,
                startTime: prevTimer.startTime,
                endTime: now,
            };
            setTimeEntries(prevEntries => [...prevEntries, newEntry]);

            // If the user clicked the SAME task that was running, it's a "stop" action.
            if (prevTimer.taskId === taskId) {
                return null; // Stop the timer by setting it to null
            } 
            // Otherwise, the user clicked a NEW task. We've already stopped the old one,
            // so now we start the new one.
            return { taskId, startTime: now }; // Start new timer
        } 
        
        // If no timer was running...
        // ...it's a simple "start" action.
        return { taskId, startTime: now }; // Start new timer
    });
  }, []);

  const tasksById = useMemo(() => {
    const map = new Map<string, Task>();
    TASKS.forEach(task => map.set(task.id, task));
    return map;
  }, []);

  const elapsedTimes = useMemo(() => {
    const newElapsedTimes = new Map<string, number>();
    const allTimeTotalsMap = new Map<string, number>();

    timeEntries.forEach(entry => {
        const duration = entry.endTime - entry.startTime;
        allTimeTotalsMap.set(entry.taskId, (allTimeTotalsMap.get(entry.taskId) || 0) + duration);
    });

    TASKS.forEach(task => {
        const totalFromEntries = allTimeTotalsMap.get(task.id) || 0;
        let activeDuration = 0;
        if (activeTimer && activeTimer.taskId === task.id) {
            activeDuration = currentTime - activeTimer.startTime;
        }
        newElapsedTimes.set(task.id, totalFromEntries + activeDuration);
    });
    return newElapsedTimes;
  }, [timeEntries, activeTimer, currentTime]);


  const handleExportCsv = useCallback(() => {
    const header = "Task Name,Start Time,End Time,Duration (HH:MM:SS)\n";
    const rows = timeEntries
      .map(entry => {
        const task = tasksById.get(entry.taskId);
        if (!task) return '';
        const startDate = new Date(entry.startTime).toLocaleString('it-IT');
        const endDate = new Date(entry.endTime).toLocaleString('it-IT');
        const durationMs = entry.endTime - entry.startTime;
        const totalSeconds = Math.floor(durationMs / 1000);
        const hours = Math.floor(totalSeconds / 3600);
        const minutes = Math.floor((totalSeconds % 3600) / 60);
        const seconds = totalSeconds % 60;
        const durationStr = [
            hours.toString().padStart(2, '0'),
            minutes.toString().padStart(2, '0'),
            seconds.toString().padStart(2, '0'),
        ].join(':');

        return `"${task.name}",${startDate},${endDate},${durationStr}`;
      })
      .join('\n');

      const csvContent = header + rows;
      const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
      const link = document.createElement('a');
      const url = URL.createObjectURL(blob);
      link.href = url;
      link.setAttribute('download', 'time_entries.csv');
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
  }, [timeEntries, tasksById]);

  const handleExportExcel = useCallback(async () => {
    try {
      // Dynamically import xlsx
      // @ts-ignore
      const { utils, writeFile } = await import('xlsx');
      
      const data = timeEntries.map(entry => {
        const task = tasksById.get(entry.taskId);
        if (!task) return null;
        
        const durationMs = entry.endTime - entry.startTime;
        const totalSeconds = Math.floor(durationMs / 1000);
        const hours = Math.floor(totalSeconds / 3600);
        const minutes = Math.floor((totalSeconds % 3600) / 60);
        const seconds = totalSeconds % 60;
        const durationStr = [
            hours.toString().padStart(2, '0'),
            minutes.toString().padStart(2, '0'),
            seconds.toString().padStart(2, '0'),
        ].join(':');

        return {
            'Attività': task.name,
            'Data': new Date(entry.startTime).toLocaleDateString('it-IT'),
            'Ora Inizio': new Date(entry.startTime).toLocaleTimeString('it-IT'),
            'Ora Fine': new Date(entry.endTime).toLocaleTimeString('it-IT'),
            'Durata': durationStr,
            'Secondi': totalSeconds
        };
      }).filter(Boolean);

      if (data.length === 0) {
        alert("Nessun dato da esportare.");
        return;
      }

      const ws = utils.json_to_sheet(data);
      
      // Set column widths
      const wscols = [
        {wch: 20}, // Task
        {wch: 12}, // Data
        {wch: 10}, // Start
        {wch: 10}, // End
        {wch: 10}, // Duration
        {wch: 10}, // Seconds
      ];
      ws['!cols'] = wscols;

      const wb = utils.book_new();
      utils.book_append_sheet(wb, ws, "Movimenti");
      writeFile(wb, `time_tracker_${new Date().toISOString().slice(0,10)}.xlsx`);
    } catch (error) {
      console.error("Failed to load xlsx or generate file", error);
      alert("Impossibile generare il file Excel. Assicurati di essere connesso a internet o che il componente sia stato caricato.");
    }
  }, [timeEntries, tasksById]);

  const handleReset = useCallback(() => {
    if (window.confirm('Sei sicuro di voler resettare tutti i dati? Questa azione è irreversibile.')) {
      setTimeEntries([]);
      setActiveTimer(null);
    }
  }, []);

  const handleInstallApp = useCallback(async () => {
    if (!deferredPrompt) return;
    // Show the install prompt
    deferredPrompt.prompt();
    // Wait for the user to respond to the prompt
    const { outcome } = await deferredPrompt.userChoice;
    console.log(`User response to the install prompt: ${outcome}`);
    // We've used the prompt, and can't use it again, throw it away
    setDeferredPrompt(null);
  }, [deferredPrompt]);

  const handleCopyUrl = async () => {
    if (!currentUrl || isBlobUrl) return;
    try {
        await navigator.clipboard.writeText(currentUrl);
        alert('Indirizzo copiato! Ora apri Chrome e incollalo.');
    } catch (err) {
        // Fallback mechanism using textarea
        const textArea = document.createElement("textarea");
        textArea.value = currentUrl;
        textArea.style.position = "fixed";
        textArea.style.left = "-9999px";
        document.body.appendChild(textArea);
        textArea.focus();
        textArea.select();
        try {
            document.execCommand('copy');
            alert('Indirizzo copiato! Ora apri Chrome e incollalo.');
        } catch (err2) {
            alert('Tieni premuto a lungo sul link blu qui sotto per copiarlo manualmente.');
        }
        document.body.removeChild(textArea);
    }
  };

  return (
    <div className="min-h-screen bg-slate-900 text-slate-100 font-sans selection:bg-sky-500/30 pb-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <header className="flex justify-between items-center py-8 border-b border-slate-800 mb-8">
          <div>
            <h1 className="text-3xl md:text-4xl font-extrabold tracking-tight bg-gradient-to-r from-sky-400 to-emerald-400 bg-clip-text text-transparent">
              Time Tracker
            </h1>
            <p className="text-slate-400 mt-1 text-sm md:text-base">Gestisci il tuo tempo con efficienza</p>
          </div>
          <div className="flex items-center gap-3">
            {deferredPrompt && !isIframe && !isBlobUrl && (
              <button
                onClick={handleInstallApp}
                className="flex items-center gap-2 py-2 px-4 rounded-xl bg-violet-600 hover:bg-violet-700 border border-violet-500 transition-all hover:shadow-lg text-white font-bold animate-pulse"
                aria-label="Installa Applicazione"
              >
                <DevicePhoneMobileIcon className="h-5 w-5" />
                <span className="hidden md:inline">Installa App</span>
              </button>
            )}
            <button
              onClick={() => setIsSettingsOpen(true)}
              className="p-3 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 transition-all hover:shadow-lg text-slate-300 hover:text-white"
              aria-label="Impostazioni"
            >
              <SettingsIcon className="h-6 w-6" />
            </button>
          </div>
        </header>

        <main className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Timers Grid */}
          <section className="lg:col-span-2 grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4">
            {TASKS.map(task => (
              <TaskTimer
                key={task.id}
                task={task}
                isActive={activeTimer?.taskId === task.id}
                isOtherTaskActive={!!activeTimer && activeTimer.taskId !== task.id}
                elapsedTime={elapsedTimes.get(task.id) || 0}
                onToggle={handleToggleTimer}
              />
            ))}
          </section>

          {/* Sidebar (Summary + History) */}
          <aside className="space-y-8 flex flex-col h-full">
            <SummaryPanel title="Riepilogo Oggi" taskTotals={elapsedTimes} />
            <div className="flex-grow">
                <TimeSheet timeEntries={timeEntries} tasksById={tasksById} />
            </div>
          </aside>
        </main>
      </div>

      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        onReset={handleReset}
        onExportCsv={handleExportCsv}
        onExportExcel={handleExportExcel}
        showInstallButton={!!deferredPrompt && !isIframe && !isBlobUrl}
        onInstall={handleInstallApp}
        currentUrl={currentUrl}
        isBlobUrl={isBlobUrl}
      />
    </div>
  );
};

export default App;