export interface Task {
  id: string;
  name: string;
  color: string;
  textColor: string;
  borderColor: string;
  glowColorHex: string;
}

export interface TimeEntry {
  id: string;
  taskId: string;
  startTime: number; // Using numbers (timestamps) for easier serialization
  endTime: number;
}

export interface ActiveTimer {
  taskId: string;
  startTime: number;
}