import type { Task } from './types';

export const TASKS: Task[] = [
  { id: 'tesoreria', name: 'Tesoreria', color: 'bg-sky-500', textColor: 'text-sky-500', borderColor: 'border-sky-500', glowColorHex: '#0ea5e9' },
  { id: 'controllo_gestione', name: 'Controllo di gestione', color: 'bg-emerald-500', textColor: 'text-emerald-500', borderColor: 'border-emerald-500', glowColorHex: '#10b981' },
  { id: 'cantieri', name: 'Cantieri', color: 'bg-amber-500', textColor: 'text-amber-500', borderColor: 'border-amber-500', glowColorHex: '#f59e0b' },
  { id: 'spagna', name: 'Spagna', color: 'bg-red-500', textColor: 'text-red-500', borderColor: 'border-red-500', glowColorHex: '#ef4444' },
  { id: 'controllate', name: 'Controllate', color: 'bg-violet-500', textColor: 'text-violet-500', borderColor: 'border-violet-500', glowColorHex: '#8b5cf6' },
  { id: 'riunioni', name: 'Riunioni', color: 'bg-pink-500', textColor: 'text-pink-500', borderColor: 'border-pink-500', glowColorHex: '#ec4899' },
];

export const LOCAL_STORAGE_KEY_ENTRIES = 'time-tracker-entries-v1';
export const LOCAL_STORAGE_KEY_TIMER = 'time-tracker-active-timer-v1';