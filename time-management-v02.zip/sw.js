
const CACHE_NAME = 'time-tracker-cache-v14';
// In a built environment (Vite), the bundler handles assets. 
// In this preview environment, we manually list them.
const URLS_TO_CACHE = [
  '/',
  '/index.html',
  '/index.tsx',
  '/App.tsx',
  '/types.ts',
  '/constants.ts',
  '/utils/time.ts',
  '/components/Icons.tsx',
  '/components/TaskTimer.tsx',
  '/components/TimeSheet.tsx',
  '/components/SummaryPanel.tsx',
  '/components/SettingsModal.tsx',
  '/manifest.json',
  '/vite.svg',
  'https://cdn.sheetjs.com/xlsx-0.20.3/package/xlsx.mjs',
  'https://cdn.tailwindcss.com',
  'https://aistudiocdn.com/react@^19.2.0',
  'https://aistudiocdn.com/react-dom@^19.2.0',
  'https://aistudiocdn.com/recharts@^3.2.1'
];

self.addEventListener('install', event => {
  self.skipWaiting();
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then(cache => {
        // Try to cache all, but don't fail if some fail (progressive)
        return Promise.all(
            URLS_TO_CACHE.map(url => {
                return cache.add(url).catch(err => console.log('Cache fail for:', url));
            })
        );
      })
  );
});

self.addEventListener('fetch', event => {
  event.respondWith(
    caches.match(event.request)
      .then(response => {
        if (response) return response;
        return fetch(event.request).then(response => {
            if(!response || response.status !== 200 || response.type !== 'basic' && response.type !== 'cors') {
              return response;
            }
            var responseToCache = response.clone();
            caches.open(CACHE_NAME).then(cache => {
                if (event.request.url.startsWith('http')) {
                   try { cache.put(event.request, responseToCache); } catch (err) {}
                }
            });
            return response;
        }).catch(() => {
            // Fallback logic could go here
        });
      })
    )
  );
});

self.addEventListener('activate', event => {
  const cacheWhitelist = [CACHE_NAME];
  event.waitUntil(
    caches.keys().then(cacheNames => {
      return Promise.all(
        cacheNames.map(cacheName => {
          if (cacheWhitelist.indexOf(cacheName) === -1) {
            return caches.delete(cacheName);
          }
        })
      );
    })
  );
});
