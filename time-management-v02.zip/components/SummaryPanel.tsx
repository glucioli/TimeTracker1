import React, { useMemo } from 'react';
import { TASKS } from '../constants';
import { formatDuration } from '../utils/time';
import type { Task } from '../types';

interface SummaryPanelProps {
    title: string;
    taskTotals: Map<string, number>;
}

const SummaryPanel: React.FC<SummaryPanelProps> = ({ title, taskTotals }) => {
    const tasksById = useMemo(() => {
        const map = new Map<string, Task>();
        TASKS.forEach(task => map.set(task.id, task));
        return map;
    }, []);

    const grandTotal = useMemo(() => {
        let total = 0;
        taskTotals.forEach(value => total += value);
        return total;
    }, [taskTotals]);

    return (
        <div className="bg-slate-800/50 backdrop-blur-sm border border-slate-700 rounded-2xl p-6">
            <h2 className="text-xl font-bold mb-6 text-slate-200">{title}</h2>
            <div className="space-y-4">
                {TASKS.map(task => {
                    const taskTime = taskTotals.get(task.id) || 0;
                    const percentage = grandTotal > 0 ? (taskTime / grandTotal) * 100 : 0;
                    return (
                        <div key={task.id}>
                            <div className="flex justify-between items-center mb-1 text-sm">
                                <div className="flex items-center gap-2">
                                    <div className={`w-2 h-2 rounded-full ${task.color}`}></div>
                                    <span className="font-semibold text-slate-300">{task.name}</span>
                                </div>
                                <span className="font-mono text-slate-200">{formatDuration(taskTime)}</span>
                            </div>
                            <div className="w-full bg-slate-700 rounded-full h-1.5">
                                <div
                                    className={`${task.color} h-1.5 rounded-full`}
                                    style={{ width: `${percentage}%` }}
                                ></div>
                            </div>
                        </div>
                    )
                })}
            </div>
            <div className="border-t border-slate-700 mt-6 pt-4 flex justify-between items-center">
                <span className="text-lg font-bold text-slate-100">Totale</span>
                <span className="text-lg font-bold font-mono text-slate-100">{formatDuration(grandTotal)}</span>
            </div>
        </div>
    );
};

export default SummaryPanel;