import React from 'react';
import type { Task } from '../types';
import { PlayIcon, StopIcon } from './Icons';
import { formatDuration } from '../utils/time';

interface TaskTimerProps {
  task: Task;
  isActive: boolean;
  isOtherTaskActive: boolean;
  elapsedTime: number;
  onToggle: (taskId: string) => void;
}

const TaskTimer: React.FC<TaskTimerProps> = ({ task, isActive, isOtherTaskActive, elapsedTime, onToggle }) => {
  const isDisabled = isOtherTaskActive && !isActive;

  const glowStyle = isActive ? { '--glow-color': task.glowColorHex } as React.CSSProperties : {};
  
  const borderClass = isDisabled
    ? 'border-slate-700'
    : isActive
    ? `animate-glow ${task.borderColor}`
    : `${task.borderColor}`;

  const buttonClass = isActive
    ? `${task.color} text-white`
    : `bg-slate-700 text-slate-300 hover:bg-slate-600`;

  return (
    <div
      style={glowStyle}
      className={`
        bg-slate-800/50 backdrop-blur-sm rounded-2xl p-6 flex flex-col justify-between h-52
        transition-all duration-300 border-2
        ${borderClass}
        ${isDisabled ? 'opacity-50 saturate-50' : ''}
      `}
    >
      <h3 className="text-lg font-semibold text-slate-100">{task.name}</h3>
      
      <div className="my-2 text-center">
        <div className="text-5xl font-mono text-slate-100 tracking-wider">
          {formatDuration(elapsedTime)}
        </div>
      </div>

      <button
        onClick={() => onToggle(task.id)}
        className={`
          w-full py-3 rounded-lg flex items-center justify-center gap-2 text-lg font-bold transition-all duration-300
          focus:outline-none focus:ring-4 focus:ring-offset-2 focus:ring-offset-slate-900
          ${buttonClass}
        `}
        aria-label={isActive ? `Stop timer for ${task.name}` : `Start timer for ${task.name}`}
      >
        {isActive ? <StopIcon className="h-6 w-6"/> : <PlayIcon className="h-6 w-6"/>}
        <span>{isActive ? 'Stop' : 'Start'}</span>
      </button>
    </div>
  );
};

export default TaskTimer;