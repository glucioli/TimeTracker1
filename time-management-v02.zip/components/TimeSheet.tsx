import React from 'react';
import type { TimeEntry, Task } from '../types';
import { formatDuration, formatTime } from '../utils/time';
import { ClockIcon } from './Icons';

interface TimeSheetProps {
  timeEntries: TimeEntry[];
  tasksById: Map<string, Task>;
}

const TimeSheet: React.FC<TimeSheetProps> = ({ timeEntries, tasksById }) => {
  const sortedEntries = [...timeEntries].sort((a, b) => b.startTime - a.startTime);

  return (
    <div className="bg-slate-800/50 backdrop-blur-sm border border-slate-700 rounded-2xl p-6 h-full">
      <h2 className="text-xl font-bold mb-6 text-slate-200">Cronologia Attività</h2>
      {sortedEntries.length === 0 ? (
        <div className="flex flex-col items-center justify-center h-48 text-slate-400">
          <ClockIcon className="h-12 w-12 mb-4" />
          <p>Nessuna attività registrata.</p>
          <p className="text-sm">Inizia un timer per tracciare il tuo tempo.</p>
        </div>
      ) : (
        <div className="space-y-3 max-h-[500px] overflow-y-auto pr-2 -mr-2">
          {sortedEntries.map(entry => {
            const task = tasksById.get(entry.taskId);
            if (!task) return null;

            const duration = entry.endTime - entry.startTime;

            return (
              <div key={entry.id} className="bg-slate-700/50 rounded-lg p-3 flex items-center justify-between transition-colors hover:bg-slate-700">
                <div className="flex items-center gap-3">
                  <div className={`w-2.5 h-2.5 rounded-full ${task.color}`}></div>
                  <div>
                    <p className="font-semibold text-slate-100">{task.name}</p>
                    <p className={`text-xs ${task.textColor}`}>
                      {formatTime(entry.startTime)} - {formatTime(entry.endTime)}
                    </p>
                  </div>
                </div>
                <div className="font-mono text-slate-200 text-sm">
                  {formatDuration(duration)}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};

export default TimeSheet;
