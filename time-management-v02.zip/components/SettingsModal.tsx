
import React from 'react';
import { CloseIcon, DownloadIcon, DevicePhoneMobileIcon, ClipboardDocumentIcon, ArrowTopRightOnSquareIcon } from './Icons';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onReset: () => void;
  onExportCsv: () => void;
  onExportExcel: () => void;
  showInstallButton?: boolean;
  onInstall?: () => void;
  currentUrl?: string;
  isBlobUrl?: boolean;
}

const SettingsModal: React.FC<SettingsModalProps> = ({ 
  isOpen, 
  onClose, 
  onReset, 
  onExportCsv, 
  onExportExcel,
  showInstallButton,
  onInstall,
  currentUrl,
  isBlobUrl
}) => {
  if (!isOpen) return null;

  const handleCopyUrl = async () => {
    if (!currentUrl) return;
    try {
        await navigator.clipboard.writeText(currentUrl);
        alert('Indirizzo copiato!');
    } catch (err) {
        const textArea = document.createElement("textarea");
        textArea.value = currentUrl;
        textArea.style.position = "fixed";
        textArea.style.left = "-9999px";
        document.body.appendChild(textArea);
        textArea.focus();
        textArea.select();
        try {
            document.execCommand('copy');
            alert('Indirizzo copiato!');
        } catch (err2) {
            alert('Copia manualmente il testo sotto.');
        }
        document.body.removeChild(textArea);
    }
  };

  return (
    <div
      className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50"
      onClick={onClose}
      aria-modal="true"
      role="dialog"
    >
      <div
        className="bg-slate-800 border border-slate-700 rounded-2xl w-full max-w-md m-4 p-6 shadow-2xl relative animate-fade-in max-h-[90vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex justify-between items-center mb-6 sticky top-0 bg-slate-800 pt-2 pb-2 z-10 border-b border-slate-700/50">
          <h2 className="text-2xl font-bold text-slate-100">Impostazioni</h2>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white transition-colors"
            aria-label="Chiudi impostazioni"
          >
            <CloseIcon className="h-7 w-7" />
          </button>
        </div>

        <div className="space-y-8 pb-4">
            {/* Sezione Installazione Manuale per Non-Esperti */}
            <div>
                <h3 className="text-lg font-semibold text-slate-300 mb-2">Come Installare su Android</h3>
                <div className="bg-slate-700/30 border border-slate-600 rounded-lg p-4">
                    <p className="text-sm text-slate-300 mb-3">
                        Hai trovato il pulsante <strong>Share</strong> sul PC? Ottimo!
                    </p>
                    <ol className="list-decimal list-inside text-sm text-slate-200 space-y-2">
                        <li>Attiva l'interruttore <strong>Publish your app</strong> (deve diventare BLU).</li>
                        <li>Premi <strong>Copy</strong> per copiare il link.</li>
                        <li>Invia quel link al tuo telefono (es. via WhatsApp).</li>
                        <li>Apri il link con <strong>Chrome</strong> sul telefono.</li>
                        <li>Tocca i tre puntini (⋮) e scegli <strong>"Installa app"</strong>.</li>
                    </ol>
                </div>
            </div>

             {/* Sezione Versione Permanente */}
             <div>
                <h3 className="text-lg font-semibold text-emerald-400 mb-2">Versione Permanente</h3>
                <div className="bg-emerald-900/10 border border-emerald-500/30 rounded-lg p-4">
                    <p className="text-sm text-slate-300 mb-3">
                        Vuoi l'app per sempre, senza dipendere dai link di anteprima?
                    </p>
                    <ol className="list-decimal list-inside text-sm text-slate-200 space-y-2">
                        <li>Su questo PC, in alto a destra, clicca l'icona <DownloadIcon className="inline h-4 w-4 align-text-bottom"/> (Download/Export).</li>
                        <li>Scarica lo <strong>ZIP</strong> del progetto.</li>
                        <li>Estrai i file e caricali su un hosting gratuito (es. <strong>Netlify Drop</strong> o <strong>GitHub Pages</strong>).</li>
                        <li>Otterrai un tuo indirizzo web personale che non scade mai.</li>
                    </ol>
                </div>
            </div>

            {/* Address Section */}
            <div>
                 <h3 className="text-lg font-semibold text-slate-300 mb-2">Indirizzo Applicazione</h3>
                 <div className="bg-slate-700/50 border border-slate-600 rounded-lg p-3">
                     {isBlobUrl ? (
                         <p className="text-sm text-red-300">
                             Attenzione: Questo è un indirizzo di anteprima privata (blob). Usa il metodo "Share" descritto sopra per ottenere il link pubblico corretto.
                         </p>
                     ) : (
                        <>
                         <p className="text-xs text-slate-400 mb-1">Link attuale:</p>
                         <div className="flex items-center gap-2">
                             <code className="flex-1 bg-slate-900 p-2 rounded text-xs font-mono text-sky-300 break-all select-all">
                                 {currentUrl || "Indirizzo non disponibile"}
                             </code>
                             <button 
                                onClick={handleCopyUrl}
                                className="p-2 bg-slate-600 hover:bg-slate-500 rounded text-white transition-colors"
                                title="Copia Link"
                             >
                                 <ClipboardDocumentIcon className="h-5 w-5" />
                             </button>
                         </div>
                         </>
                     )}
                 </div>
            </div>

            {showInstallButton && (
            <div>
                <h3 className="text-lg font-semibold text-slate-300 mb-2">Installazione Rapida</h3>
                <div className="bg-violet-900/20 border border-violet-500/30 rounded-lg p-4 flex items-center justify-between">
                    <div>
                        <p className="font-bold text-violet-200">Installa App</p>
                        <p className="text-sm text-violet-300/80">Usa come app nativa</p>
                    </div>
                    <button
                        onClick={onInstall}
                        className="bg-violet-600 hover:bg-violet-700 text-white font-bold py-2 px-4 rounded-lg transition-colors focus:outline-none focus:ring-2 focus:ring-violet-500 focus:ring-offset-2 focus:ring-offset-slate-800 flex items-center gap-2"
                    >
                        <DevicePhoneMobileIcon />
                        <span>Installa</span>
                    </button>
                </div>
            </div>
            )}

            <div>
                <h3 className="text-lg font-semibold text-slate-300 mb-2">Esportazione Dati</h3>
                <div className="bg-slate-700/50 border border-slate-600 rounded-lg p-4 space-y-4">
                    <div className="flex items-center justify-between">
                        <div>
                            <p className="font-bold text-slate-200">Esporta Excel</p>
                            <p className="text-sm text-slate-400">Migliore per PC</p>
                        </div>
                        <button
                            onClick={onExportExcel}
                            className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-2 px-4 rounded-lg transition-colors focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:ring-offset-2 focus:ring-offset-slate-800 flex items-center gap-2"
                        >
                            <DownloadIcon />
                            <span>Excel</span>
                        </button>
                    </div>

                    <div className="flex items-center justify-between border-t border-slate-600 pt-4">
                         <div>
                            <p className="font-bold text-slate-200">Esporta CSV</p>
                            <p className="text-sm text-slate-400">Formato semplice</p>
                        </div>
                        <button
                            onClick={onExportCsv}
                            className="bg-sky-600 hover:bg-sky-700 text-white font-bold py-2 px-4 rounded-lg transition-colors focus:outline-none focus:ring-2 focus:ring-sky-500 focus:ring-offset-2 focus:ring-offset-slate-800 flex items-center gap-2"
                        >
                            <DownloadIcon />
                            <span>CSV</span>
                        </button>
                    </div>
                </div>
            </div>

            <div>
                <h3 className="text-lg font-semibold text-slate-300 mb-2">Area Pericolosa</h3>
                <div className="bg-red-900/20 border border-red-500/30 rounded-lg p-4 flex items-center justify-between">
                    <div>
                        <p className="font-bold text-red-200">Resetta Tutto</p>
                        <p className="text-sm text-red-300/80">Cancella tutti i dati.</p>
                    </div>
                    <button
                        onClick={onReset}
                        className="bg-red-600 hover:bg-red-700 text-white font-bold py-2 px-4 rounded-lg transition-colors focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-offset-2 focus:ring-offset-slate-800"
                    >
                        Resetta
                    </button>
                </div>
            </div>
        </div>
      </div>
    </div>
  );
};

export default SettingsModal;